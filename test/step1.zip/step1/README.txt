# Micro.bat uses Compilers.jar to implement the littleLexer that parses the input file
# It currently requires a folder called "inputs" in the same directory, which houses the .micro files
# To run the file simply type the following command at a Windows Command Prompt:

C:\step1> micro.bat [input.micro]

# Where input is the name of the micro file inside the inputs/ folder